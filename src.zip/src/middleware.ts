// src/middleware.ts
// Handles:
//  1. Security headers on all responses
//  2. Admin route protection — redirects to /admin/login if no valid Supabase session
//
// KEY FIX: The cookie set/remove handlers must actually write back to the response.
// Without them, Supabase cannot persist the session cookie and the middleware
// always sees an empty session → infinite redirect loop.

import { defineMiddleware } from 'astro:middleware';
import { createServerClient } from '@supabase/ssr';

export const onRequest = defineMiddleware(async (context, next) => {
  const { cookies, url, redirect } = context;

  // Admin guard (runs before calling next() so we can redirect early)
  if (url.pathname.startsWith('/admin') && url.pathname !== '/admin/login') {
    const supabase = createServerClient(
      import.meta.env.PUBLIC_SUPABASE_URL,
      import.meta.env.PUBLIC_SUPABASE_ANON_KEY,
      {
        cookies: {
          get(key) {
            return cookies.get(key)?.value;
          },
          // These two MUST be implemented — Supabase needs to refresh & persist tokens
          set(key, value, options) {
            cookies.set(key, value, {
              ...options,
              // Ensure cookies work on localhost during development
              sameSite: options?.sameSite ?? 'lax',
              secure: url.protocol === 'https:',
              httpOnly: true,
            });
          },
          remove(key, options) {
            cookies.delete(key, options);
          },
        },
      }
    );

    const {
      data: { session },
    } = await supabase.auth.getSession();

    if (!session) {
      return redirect('/admin/login');
    }
  }

  // Call next to get the real response
  const response = await next();

  // Append security headers (Cloudflare wrangler.toml also sets these — belt & braces)
  response.headers.set('X-Frame-Options', 'DENY');
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');

  return response;
});
